package com.leafBot.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.events.EventFiringWebDriver;
import org.xml.sax.Locator;
import com.aventstack.extentreports.ExtentTest;
import com.leafBot.testng.api.base.ProjectSpecificMethods;

import cucumber.api.java.en.Then;

public class CreateLead extends ProjectSpecificMethods{

	public CreateLead(RemoteWebDriver driver, ExtentTest node) {
		this.driver = driver;
		this.node = node;
	}
	public CreateLead enterCompnyName(String data) {
		clearAndType(locateElement("xpath", "(//input[@name='companyName'][1])[2]"), data);
		return this;
	}
	public CreateLead enterFirstName(String data) {
		clearAndType(locateElement("xpath", "(//input[@name='firstName'])[3]"), data);
		return this;
	}
	public CreateLead enterLastName(String data) {
		clearAndType(locateElement("xpath", "(//input[@name='lastName'])[3]"), data);
		return this;
	}
	public CreateLead enterPhoneNum(String data) {
		clearAndType(locateElement("id", "createLeadForm_primaryPhoneNumber"), data);
		return this;
	}
	public CreateLead enterEmail(String data) {
		clearAndType(locateElement("id", "createLeadForm_primaryEmail"), data);
		return this;
	}
	public ViewLead clickCreateLeadButton() {
		click(locateElement("xpath", "(//input[@name='submitButton'])"));
		return new ViewLead(driver, node);
	}

	
	

}










