package com.leafBot.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.events.EventFiringWebDriver;
import org.xml.sax.Locator;
import com.aventstack.extentreports.ExtentTest;
import com.leafBot.testng.api.base.ProjectSpecificMethods;

import cucumber.api.java.en.Then;

public class ViewLead extends ProjectSpecificMethods{

	public ViewLead(RemoteWebDriver driver, ExtentTest node) {
		this.driver = driver;
		this.node = node;
	}
	public  ViewLead viewLeadNumber() {
		String leadNum =getElementText(locateElement("id", "viewLead_companyName_sp"));
		System.out.println(leadNum);
		return this;
	}
	public  EditLead clickEditbutton() {
		
		click(locateElement("xpath", "//a[@class='subMenuButton' and text()='Edit']"));
		return new EditLead(driver, node);
	}
	
	public  DuplicateLead clickDuplicatebutton() {
		click(locateElement("link", "Duplicate Lead"));
		return new DuplicateLead(driver, node);
	}
	public  MyLeads clickDeletebutton() throws InterruptedException {
		click(locateElement("xpath", "//a[@class='subMenuButtonDangerous' and text()='Delete']"));
		Thread.sleep(4000);
		return new MyLeads(driver, node);
	}

}










