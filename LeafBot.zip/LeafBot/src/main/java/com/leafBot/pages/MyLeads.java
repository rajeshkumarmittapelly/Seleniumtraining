package com.leafBot.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.events.EventFiringWebDriver;
import org.xml.sax.Locator;
import com.aventstack.extentreports.ExtentTest;
import com.leafBot.testng.api.base.ProjectSpecificMethods;

import cucumber.api.java.en.Then;

public class MyLeads extends ProjectSpecificMethods{

	public MyLeads(RemoteWebDriver driver, ExtentTest node) {
		this.driver = driver;
		this.node = node;
	}
	
	public CreateLead clickCreaLead() {
		
		click(locateElement("xpath","//a[(text()='Create Lead')]"));
		return new CreateLead(driver, node);
	}

	
	public FindLead findLead() {
		click(locateElement("xpath","//a[text()='Find Leads']"));
		return new FindLead(driver, node);
	}
	public MergeLead clickMergeLead() {
		click(locateElement("link","Merge Leads"));
		
		return new MergeLead(driver, node);
	}

}










