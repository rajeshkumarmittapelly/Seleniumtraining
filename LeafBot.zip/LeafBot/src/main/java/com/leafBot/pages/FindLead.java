package com.leafBot.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.events.EventFiringWebDriver;
import org.xml.sax.Locator;
import com.aventstack.extentreports.ExtentTest;
import com.leafBot.testng.api.base.ProjectSpecificMethods;

import cucumber.api.java.en.Then;

public class FindLead extends ProjectSpecificMethods{

	public FindLead(RemoteWebDriver driver, ExtentTest node) {
		this.driver = driver;
		this.node = node;
	}
	
	public FindLead enterCmpnyName(String companyName) {
		
		clearAndType(locateElement("xpath", "(//input[@name='companyName'])[2]"), companyName);
		return this;
	}
	public FindLead enterLeadID() {
		clearAndType(locateElement("xpath", "//input[@name='id']"), leadNumber);
		return this;
	}
	public FindLead clickFindLeadbtn() throws Exception {
		
		click(locateElement("xpath", "//button[text()='Find Leads']"));
		Thread.sleep(2000);
		return this;
	}
	public FindLead clickEmailTab() throws Exception {
		click(locateElement("xpath", "//span[text()='Email']"));
		return this;
		
	}
	public FindLead clickPhoneTab() throws Exception {
		click(locateElement("xpath", "//span[text()='Phone']"));
		return this;
		
	}
	public FindLead enterPhoneNum(String phoneNum) {
		clearAndType(locateElement("xpath", "//input[@name='phoneNumber']"), phoneNum);
		return this;
	}
	
	public FindLead enterEmail(String email) throws Exception {
		clearAndType(locateElement("xpath", "//input[@name='emailAddress']"), email);
		Thread.sleep(2000);
		return this;
	}
	public ViewLead clickLeadNumber() throws Exception {
		
		leadNumber = getElementText(locateElement("xpath", "(//div[@class='x-grid3-cell-inner x-grid3-col-partyId']/a)[1]"));
		click(locateElement("xpath", "(//div[@class='x-grid3-cell-inner x-grid3-col-partyId']/a)[1]"));
		
		
		//setLeadNum(leadNum);
		
		System.out.println("Completeting clickLeadNumber");
		return new ViewLead(driver, node);
	}
	public FindLead verifyNoErrorMessage() {
		String msg =getElementText(locateElement("xpath", "//div[@class='x-toolbar x-small-editor']/div"));
		
		System.out.println("Message is matching? "+msg.equalsIgnoreCase("No records to display"));
		return this;
	}

}










