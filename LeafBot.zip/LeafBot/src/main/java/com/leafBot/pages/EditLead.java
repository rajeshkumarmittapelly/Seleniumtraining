package com.leafBot.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.events.EventFiringWebDriver;
import org.xml.sax.Locator;
import com.aventstack.extentreports.ExtentTest;
import com.leafBot.testng.api.base.ProjectSpecificMethods;

import cucumber.api.java.en.Then;

public class EditLead extends ProjectSpecificMethods{
	public EditLead(RemoteWebDriver driver, ExtentTest node) {
		this.driver = driver;
		this.node = node;
	}
	
	public EditLead editCompnyName(String data) {
		clearAndType(locateElement("id", "updateLeadForm_companyName"), data);		
		return this;
	}
	
	public ViewLead clickUpdateLeadButton() {
		click(locateElement("xpath", "//input[@name='submitButton' and @value='Update']"));
		return new ViewLead(driver, node);
	}

}
