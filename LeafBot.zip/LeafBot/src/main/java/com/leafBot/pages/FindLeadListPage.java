package com.leafBot.pages;

import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.events.EventFiringWebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.xml.sax.Locator;
import com.aventstack.extentreports.ExtentTest;
import com.leafBot.testng.api.base.ProjectSpecificMethods;

import cucumber.api.java.en.Then;

public class FindLeadListPage extends ProjectSpecificMethods{

	public FindLeadListPage(RemoteWebDriver driver, ExtentTest node) {
		this.driver = driver;
		this.node = node;
	}
	
	public FindLeadListPage enterLastName(String data) {
		clearAndType(locateElement("name", "lastName"), data);
		return new FindLeadListPage(driver, node);
	}

	public FindLeadListPage clickFindLeads() throws InterruptedException {
		
		click(locateElement("xpath", "//button[text()='Find Leads']"));
		return new FindLeadListPage(driver, node);
	}

	public MergeLead selectLead1() {
		
		try {
			if (driver.getTitle().contains("Find Leads")) {
				
				click(locateElement("xpath", "(//div[@class='x-grid3-cell-inner x-grid3-col-partyId']/a)[1]"));
			}
		} catch (StaleElementReferenceException e) {
			// TODO Auto-generated catch block
			if (driver.getTitle().contains("Find Leads")) {
				click(locateElement("xpath", "(//div[@class='x-grid3-cell-inner x-grid3-col-partyId']/a)[1]"));
			}
		}
		switchToWindow("Merge Leads | opentaps CRM");
		
		return new MergeLead(driver, node);
	}

	public MergeLead selectLead2() {
		try {
			if (driver.getTitle().contains("Find Leads")) {
				click(locateElement("xpath", "(//div[@class='x-grid3-cell-inner x-grid3-col-partyId']/a)[2]"));

			}
		} catch (StaleElementReferenceException e) {
			// TODO Auto-generated catch block
			if (driver.getTitle().contains("Find Leads")) {
				click(locateElement("xpath", "(//div[@class='x-grid3-cell-inner x-grid3-col-partyId']/a)[2]"));

			}
		}

		switchToWindow("Merge Leads | opentaps CRM");
		return new MergeLead(driver, node);
	}

	
	

}










