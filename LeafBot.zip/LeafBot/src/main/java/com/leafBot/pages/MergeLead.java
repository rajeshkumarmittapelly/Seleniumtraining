package com.leafBot.pages;

import java.util.Set;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.events.EventFiringWebDriver;
import org.xml.sax.Locator;
import com.aventstack.extentreports.ExtentTest;
import com.leafBot.testng.api.base.ProjectSpecificMethods;

import cucumber.api.java.en.Then;

public class MergeLead extends ProjectSpecificMethods {

	public MergeLead(RemoteWebDriver driver, ExtentTest node) {
		this.driver = driver;
		this.node = node;
	}

	public FindLeadListPage clickfirstLookup() {
		click(locateElement("xpath", "(//img[@alt='Lookup'])[1]"));
		switchToWindow("Find Leads");
		return new FindLeadListPage(driver, node);

	}

	public FindLeadListPage clickSecondLookup() {
		if (driver.getTitle().contains("Merge Leads")) {
			click(locateElement("xpath", "(//img[@alt='Lookup'])[2]"));
		}
		switchToWindow("Find Leads");
		return new FindLeadListPage(driver, node);

	}

	public ViewLead clickMergeButton() {
		driver.findElementByXPath("//a[text()='Merge']").click();
		acceptAlert();
		return new ViewLead(driver, node);
	}
}
