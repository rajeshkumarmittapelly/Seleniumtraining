package com.leafBot.testcases;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.leafBot.pages.LoginPage;
import com.leafBot.testng.api.base.ProjectSpecificMethods;

public class TC007_DeleteLead extends ProjectSpecificMethods{

	@BeforeTest
	public void setValues() {

		testCaseName = "Duplicate Lead";
		testDescription = "Duplicate the Lead in LeafTap";
		nodes = "Leads";
		authors = "Rajesh";
		category = "Regression";
		dataSheetName = "TC007";

	}

	@Test(dataProvider = "fetchData")
	public void duplicateLead(String uName, String pwd, String eMail) throws Exception {
		new LoginPage(driver, node)
		.enterUserName(uName)
		.enterPassword(pwd)
		.clickLogin()
		.clickCRMSFA()
		.clickLeadsTab()
		.findLead()
		.clickEmailTab()
		.enterEmail(eMail)
		.clickFindLeadbtn()
		.clickLeadNumber()
		.clickDeletebutton()
		.findLead()
		.enterLeadID()
		.clickFindLeadbtn()
		.verifyNoErrorMessage();
	}


}





