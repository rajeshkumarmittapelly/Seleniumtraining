package com.leafBot.testcases;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

public class sample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Properties prop = new Properties();
		try {
			prop.load(new FileInputStream(new File(".//config.properties")));
			String sHubUrl = prop.getProperty("HUB");
			String sHubPort = prop.getProperty("PORT");
			
			System.out.println(sHubPort+sHubUrl);
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}
