package com.leafBot.testcases;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.leafBot.pages.LoginPage;
import com.leafBot.testng.api.base.ProjectSpecificMethods;

public class TC004_EditLead extends ProjectSpecificMethods{

	@BeforeTest
	public void setValues() {

		testCaseName = "Edit Lead";
		testDescription = "Editing the Lead in LeafTap";
		nodes = "Leads";
		authors = "Rajesh";
		category = "Regression";
		dataSheetName = "TC004";

	}

	@Test(dataProvider = "fetchData")
	public void editLead(String uName, String pwd, String cName, String uCName) throws Exception {
		new LoginPage(driver, node)
		.enterUserName(uName)
		.enterPassword(pwd)
		.clickLogin()
		.clickCRMSFA()
		.clickLeadsTab()
		.findLead()
		.enterCmpnyName(cName)
		.clickFindLeadbtn()
		.clickLeadNumber()
		.clickEditbutton()
		.editCompnyName(uCName)
		.clickUpdateLeadButton()
		.viewLeadNumber();
	}


}





