package com.leafBot.testcases;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.leafBot.pages.LoginPage;
import com.leafBot.testng.api.base.ProjectSpecificMethods;

public class TC006_MergeLead extends ProjectSpecificMethods{

	@BeforeTest
	public void setValues() {

		testCaseName = "Merge Lead";
		testDescription = "Merge Lead in LeafTap";
		nodes = "Leads";
		authors = "Rajesh";
		category = "Regression";
		dataSheetName = "TC006";

	}

	@Test(dataProvider = "fetchData")
	public void mergeLead(String uName, String pwd, String  lName) throws InterruptedException {
		new LoginPage(driver, node)
		.enterUserName(uName)
		.enterPassword(pwd)
		.clickLogin()
		.clickCRMSFA()
		.clickLeadsTab()
		.clickMergeLead()
		.clickfirstLookup()
		//.enterLastName(lName)
		.clickFindLeads()
		.selectLead1()
		.clickSecondLookup()
		.enterLastName(lName)
		.clickFindLeads()
		.selectLead2()
		.clickMergeButton()
		.viewLeadNumber()
		;
	}


}





